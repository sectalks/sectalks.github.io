#include <stdio.h>
#include <string.h>

char * username = "admin";
char * password = "hunter2";

void success(void) {
  printf("flag{hack_the_planet}\n");
}

void failure(const char * user) {
  printf("failed to login in as '");
  printf(user);
  printf("'\n");
}

int main(int argc, char ** argv) {
  printf(":: hack.Sydney\n");

  if (argc < 3) {
    printf("usage: %s <user> <pass>\n", argv[0]);
    return 0;
  }

  char user[32] = {0};
  char pass[32] = {0};
  strcpy(user, argv[1]);
  strcpy(pass, argv[2]);

  if (!strcmp(username, user) && !strcmp(password, pass)) {
    success();
  } else {
    failure(user);
  }

  return 0;
}
